import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
     <h1>My Goals for Life</h1>
     <ol>
      <li>Job</li>
      <li>Home</li>
      <li>Money</li>
      <li>More Money</li>
      
     </ol>
    </div>
  );
}

export default App;
